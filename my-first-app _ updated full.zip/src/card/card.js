import React,{Component} from "react";
import './card.scss'

 const Card=(props)=>{
  console.log(props); //to kknow what is props
  return (<div className="card-container">
       <img src={`https://robohash.org/${props.hero.id}?set=set2`} alt='no image'/>
 {props.hero.id}  {props.hero.name}</div>);
}

export default Card;