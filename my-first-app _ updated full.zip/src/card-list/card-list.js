import React,{Component} from "react";
import './card-list.scss';
import Card from '../card/card'
 export default class Cardlist extends Component {
  
   render(){
     
   return (
      <div className='card-list'>
       {
        this.props.data.map((avengers,index)=>(<div key={index}> <Card key={avengers.id} hero={avengers}/></div>))
        }
        </div>
    );
}
 }

{/* <div className='card-list'>{this.props.children}</div> keep this in return of render*/}