import React from 'react';
import logo from './logo.svg';
import './App.css';
import Cardlist from './card-list/card-list'
class App extends React.Component {
  constructor() {
    super();
    console.log('in constr');
    this.state = {
      avengers: [
        { name: 'IronMan', id: 'Av1001', superPower: 'suit' },
        { name: 'SpiderMan', id: 'Av1002', superPower: 'web' },
        { name: 'Captain America', id: 'Av1003', superPower: 'shield' },
        { name: 'Hulk', id: 'Av1004', superPower: 'smash' }
      ],
      search:''
    }
  }
  componentWillMount() {
    console.log('comp is about to be mounted');
    fetch('https://jsonplaceholder.typicode.com/users').then(
      response => response.json()
    )
      .then(av => this.setState({ avengers: av }))
  }

  searchHeros = (event) => {
    this.setState({search:event.target.value});
    //console.log(event.target.value);
  }
  render() {
    console.log('in render');
    //2 temp variable one too store serach value and other to store filtered value
    //const {heroTemp,searchData}=this.state;  = implement destructing

   
    let searchBoxVal = this.state.search

    //filter the data in array      
  const filteredHero=this.state.avengers.filter(
  m=>m.name.toLowerCase().includes(searchBoxVal.toLowerCase()));


    let myStyle = { margin: 90, paddingBottom: 20 }
    return (
      <div className="container-fluid">
        {/* <div style={{ margin:90 ,paddingBottom:20}}> */}
        <div style={myStyle}>
          <input type='search' placeholder='search heros' onChange={this.searchHeros} />

        </div>
        {/* passing the filtered data to child comp */}
        <Cardlist data={filteredHero} />

      </div>
    );
  }
  componentDidMount() {
    console.log('comp has been mounted');
  }
  componentWillUnmount() { }
  comp
}

export default App;
{/* <Cardlist>
{this.state.avengers.map((aven)=>
<div><h1 key={aven.id}>{aven.name}</h1>
<h3>{aven.superPower}</h3></div>
)} 
</Cardlist> */}