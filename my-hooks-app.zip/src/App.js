import React ,{useState, useEffect}from 'react';
import Route from 'react-router-dom';

import './App.css';

function App() {
  const [name,setName]=useState('ajay');
  const [city,setCity]=useState('Mumbai');
  const [obj,setObj]=useState({pName:'def',price:'0'});

  useEffect(()=>{console.log('hi i am use effect hook')},[name,city,obj]);
  // const[variable who maintains state,setter method of that variable]
  //method name can be anything
  return (
    <div className="App">
      
      <h1>{name}</h1>
      <button onClick={()=>setName('david')}>click to change name</button>
      <h1>{city}</h1>
      <button onClick={()=>setCity('Chennai')}>click to change city</button>
      <h1>{obj.pName}</h1>
      <button onClick={()=>setObj({...obj,pName:'david copperfield'})}>click to change product name</button>
      <h1>{obj.price}</h1>
      <button onClick={()=>setObj({...obj,price:'4000'})}>click to change product price</button>

      {JSON.stringify(obj)}
    </div>
  );
}

export default App;
